console.log("Homework 1")

let price = 119.95;
let taxRate = 5;
let amount = 30;
let priceOfAll = price * amount ;
console.log(priceOfAll)

let tax = (priceOfAll * taxRate)/100;
console.log(tax) 

let finalPrice = priceOfAll  + tax
console.log(finalPrice)


